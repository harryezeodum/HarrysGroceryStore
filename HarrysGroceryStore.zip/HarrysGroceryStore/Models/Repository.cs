﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HarrysGroceryStore.Models
{
    public class Repository
    {
        public static List<Registration> responses = new List<Registration>();
        public static IEnumerable<Registration> Responses = responses;
        public static void AddResponse(Registration response)
        {
            responses.Add(response);
        }

        public static void EditResponse(Registration response)
        {
            responses.Add(response);

        }
    }
}
