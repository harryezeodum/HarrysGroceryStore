﻿using HarrysGroceryStore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace HarrysGroceryStore.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult WelcomePage()
        {
            return View();
        }

        [HttpGet]
        public IActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SignUp(Registration registration)
        {
            if (ModelState.IsValid)
            {
                if (registration.PassWord == registration.ConfirmPassword)
                {
                    Repository.AddResponse(registration);
                    return RedirectToAction("SignOnPage");
                }
                ModelState.AddModelError("", "Password don't match");
            }
            return View();
        }

        public IActionResult SignOnPage()
        {
            return View();
        }

        public ViewResult ProfileDetails()
        {
            return View(Repository.Responses);
        }

        [HttpGet]
        public IActionResult EditProfile(string firstName)
        {
            Registration information = new Registration();
            information.FirstName = firstName;
            information.LastName = "Smith";
            information.Email = "michael.smith@aol.com";
            information.PhoneNumber = "210-712-2100";
            information.PassWord = "1234";
            information.ConfirmPassword = "1234";
            return View(information);
        }

        [HttpPost]
        public IActionResult EditProfile(Registration edit)
        {
            if (ModelState.IsValid)
            {
                if (edit.PassWord == edit.ConfirmPassword)
                {
                    Repository.EditResponse(edit);
                    return RedirectToAction("ProfileDetails", edit); ;
                }
                ModelState.AddModelError("", "Password don't match");
            }
            return View(edit);
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}
